# Import necessary packages
import cv2
import numpy as np
from tensorflow.lite.python.interpreter import Interpreter

# Load your TFLite model and label map
model_path = "C:/Users/Hubert Spencer/Documents/Visual Studio 2022/python/my_elephant_detecting/custom_model_lite/detect.tflite"
label_path = "C:/Users/Hubert Spencer/Documents/Visual Studio 2022/python/my_elephant_detecting/custom_model_lite/labelmap.txt"  # Update with the actual path

interpreter = Interpreter(model_path=model_path)
interpreter.allocate_tensors()

# Get model details
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
height, width = input_details[0]['shape'][1], input_details[0]['shape'][2]

# Load the label map into memory
with open(label_path, 'r') as f:
    labels = [line.strip() for line in f.readlines()]

# Initialize camera
cap = cv2.VideoCapture(0)  # Use 0 for the default camera, change to another number if you have multiple cameras

while True:
    # Read a frame from the camera
    ret, frame = cap.read()

    # Convert the frame to FLOAT32
    input_data = frame.astype(np.float32)

    # Resize the frame to match the model input shape
    input_data = cv2.resize(input_data, (width, height))
    input_data = np.expand_dims(input_data, axis=0)

    # Perform the actual detection by running the model with the frame as input
    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    # Retrieve detection results
    boxes = interpreter.get_tensor(output_details[0]['index'])[0]
    classes = interpreter.get_tensor(output_details[1]['index'])[0]
    scores = interpreter.get_tensor(output_details[2]['index'])[0]

    # Loop over all detections and draw detection box if confidence is above a minimum threshold
    if np.isscalar(scores) and np.isscalar(boxes):
        # Handle the case when there is only one detection
        if scores > 0.5:  # Adjust the threshold as needed
            ymin, xmin, ymax, xmax = boxes
            ymin, xmin, ymax, xmax = int(ymin * frame.shape[0]), int(xmin * frame.shape[1]), int(ymax * frame.shape[0]), int(xmax * frame.shape[1])
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
            cv2.putText(frame, labels[int(classes)], (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    else:
        for i in range(len(scores)):
            if scores[i] > 0.5:  # Adjust the threshold as needed
                ymin, xmin, ymax, xmax = boxes[i]
                ymin, xmin, ymax, xmax = int(ymin * frame.shape[0]), int(xmin * frame.shape[1]), int(ymax * frame.shape[0]), int(xmax * frame.shape[1])
                cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                cv2.putText(frame, labels[int(classes[i])], (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Display the resulting frame
    cv2.imshow('Object Detection', frame)

    # Break the loop when 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
